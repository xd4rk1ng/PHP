<img src="{{ $sourceImage }}" alt="..." 
     style="width: 100%; height: 100%; object-fit: cover;">