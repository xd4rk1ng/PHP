<div class="container">
    <div class="row">
        <div class="col-12">
            <p class="text-center"> Website by Rui using <a href="https://getbootstrap.com">Bootstrap</a>.</p>
        </div>
    </div>
</div>
