<div class="container">
    <div class="row mb-2">
        <div class="col-md-6 ">
            <?php $__env->startComponent("components.sections.{$type_1}", ['sourceImage' => $src]); ?>
            <?php if (isset($__componentOriginale63423cc28ddce2c0c1cf680e63b84cf5c3d3ef4)): ?>
<?php $component = $__componentOriginale63423cc28ddce2c0c1cf680e63b84cf5c3d3ef4; ?>
<?php unset($__componentOriginale63423cc28ddce2c0c1cf680e63b84cf5c3d3ef4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>
        <div class="col-md-6 ">
            <?php $__env->startComponent("components.sections.{$type_2}", ['sourceImage' => $src]); ?>
            <?php if (isset($__componentOriginald2a822b0cf29952587871ee2ad5145ac51f24dc0)): ?>
<?php $component = $__componentOriginald2a822b0cf29952587871ee2ad5145ac51f24dc0; ?>
<?php unset($__componentOriginald2a822b0cf29952587871ee2ad5145ac51f24dc0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>
        <hr width="100%">
    </div>
</div>
<?php /**PATH C:\Users\Rui Santos\GitHub\php\projAldi\projAldi\resources\views/components/sections/section.blade.php ENDPATH**/ ?>