<div class="container">
    <div class="row mb-3">
        <div class="col-md-4 mt-5">
            <?php $__env->startComponent("components.cards.card", [
                'source' => $image1
            ]); ?>
            <?php if (isset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8)): ?>
<?php $component = $__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8; ?>
<?php unset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>
        <div class="col-md-4 mt-5">
            <?php $__env->startComponent("components.cards.card", [
                'source' => $image2
            ]); ?>
            <?php if (isset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8)): ?>
<?php $component = $__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8; ?>
<?php unset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>
        <div class="col-md-4 mt-5">
            <?php $__env->startComponent("components.cards.card", [
                'source' => $image3
            ]); ?>
            <?php if (isset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8)): ?>
<?php $component = $__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8; ?>
<?php unset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Rui Santos\GitHub\php\projAldi\projAldi\resources\views/components/cards/cards.blade.php ENDPATH**/ ?>